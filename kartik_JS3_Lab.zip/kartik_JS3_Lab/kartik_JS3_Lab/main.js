import {WeatherApp} from "./weather-app/weather-app.js";

const weatherApp = new WeatherApp();
weatherApp.init();